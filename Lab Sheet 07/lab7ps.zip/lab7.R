getwd()
setwd("C:\\Users\\B E S T  COMPUTER\\Desktop\\Lab07")

a <- 0      
b <- 40    
p_train <- (25 - 10) / (b - a)
p_train

lambda <- 1/3
p_update <- pexp(2, rate = lambda)
p_update

mu <- 100
sigma <- 15

p_iq_above130 <- 1 - pnorm(130, mean = mu, sd = sigma)
p_iq_above130

iq_95th <- qnorm(0.95, mean = mu, sd = sigma)
iq_95th
